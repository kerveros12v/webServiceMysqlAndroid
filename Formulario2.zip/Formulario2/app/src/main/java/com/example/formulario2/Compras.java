package com.example.formulario2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Compras extends AppCompatActivity {
    EditText comcodig,comcantidad;
    TextView comdetall,comstock,comprecio,comtotal,comprasUtilidad,txtutilidadcomp;
    Double precio1;
    Double stk;
    RequestQueue requestQueue;
    String urlbase="http://192.168.0.105/formulario/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compras);
        comcodig=(EditText)findViewById(R.id.etcomprascodigo);
        comcantidad=(EditText)findViewById(R.id.etcomprascantidad);
        comdetall=(TextView)findViewById(R.id.etvcomprasdetalle);
        comstock=(TextView)findViewById(R.id.etvcomprasStock);
        comprecio=(TextView)findViewById(R.id.etvcomprasprecio);
        comtotal=(TextView)findViewById(R.id.etvcomprastotal);
        comprasUtilidad=(TextView)findViewById(R.id.comprasUtilidad);
        txtutilidadcomp=(TextView)findViewById(R.id.txtutilidadcomp);
    }
    private void buscar(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        comcodig.setText(jsonObject.getString("codigo"));
                        comdetall.setText(jsonObject.getString("nombre"));
                        comstock.setText(jsonObject.getString("stock"));
                        comprecio.setText(jsonObject.getString("precioCosto"));
                        precio1=Double.parseDouble(jsonObject.getString("ganancia"));
                        txtutilidadcomp.setText(jsonObject.getString("precioVenta"));
                        stk=Double.parseDouble(jsonObject.getString("stock"));
                        Toast.makeText(getApplicationContext(), "Registro encontrado", Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
               mensajeAlert(error.getMessage(),"Error en el Servidor");
            }
        }
        );
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    private void ejecutarServico(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                mensajeAlert(response.toString(), "Respuesta del servidor");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mensajeAlert(error.toString(),"Error desde el Servidor");
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("codigo",comcodig.getText().toString());
                parametros.put("nombre",comdetall.getText().toString());
                parametros.put("stock",comstock.getText().toString());
                parametros.put("precioCosto",comprecio.getText().toString());

                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
        Toast.makeText(this,"Servicio ejecutado con exito",Toast.LENGTH_LONG).show();
    }
    public void consultaporcodigo(View view) {
        buscar(urlbase+"buscarProducto.php?codigo="+comcodig.getText().toString());
    }

    public void totalPagar(View view){
        try {
            double p1 = Double.parseDouble(comprecio.getText().toString());
            double cant1 = Double.parseDouble(comcantidad.getText().toString());
            double total = p1 * cant1;
            comtotal.setText("Total:  " + total);
            double uti=Double.parseDouble( txtutilidadcomp.getText().toString());
            comprasUtilidad.setText("Utilidad: "+((uti-p1)*cant1));
        }catch (Exception e){
            mensajeAlert(e.getMessage(),"Calculo del Total");
        }
    }
    public void modificacion(View view) {
        double cant1=Double.parseDouble(comcantidad.getText().toString());
        if(cant1>=1) {
            stk = stk + cant1;
            String stock = stk + "";
            comstock.setText(stock);
            ejecutarServico(urlbase+"actualizarproductoCompra.php");
        }
        else{
            Toast.makeText(this, "La cantidad a comprar es mayor al stock actual",
                    Toast.LENGTH_SHORT).show();
        }
    }
    private void  mensajeAlert(String e,String titulo){
        AlertDialog.Builder builder=new AlertDialog.Builder(Compras.this);
        builder.setMessage(e);
        builder.setTitle(titulo);
        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog= builder.create();
        dialog.show();
    }
    public void regresar(View view){
        Intent i=null;
            i = new Intent(this, Inventario.class );

        startActivity(i);
    }
    /*version sqllite
      public void consultaporcodigo(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = comcodig.getText().toString();
        Cursor fila = bd.rawQuery(
                "select descripcion,stock,venta from producto where codigo=" + cod, null);
        if (fila.moveToFirst()) {
            comdetall.setText("Descripcion:   " + fila.getString(0));
            comstock.setText("Stock:         "+fila.getString(1));
            comprecio.setText("Precio:        "+fila.getString(2));
            precio1=Double.parseDouble(fila.getString(2));
            stk=Double.parseDouble(fila.getString(1));
        } else
            Toast.makeText(this, "No existe un producto con dicho código",
                    Toast.LENGTH_SHORT).show();
        bd.close();
    }
    public void modificacion(View v) {
        double cant1=Double.parseDouble(comcantidad.getText().toString());
        if(cant1>=1) {
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                    "administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();
            String cod = comcodig.getText().toString();
            stk = stk + cant1;
            String stock = stk + "";
            ContentValues registro = new ContentValues();
            registro.put("stock", stock);
            int cant = bd.update("producto", registro, "codigo=" + cod, null);
            bd.close();
            if (cant == 1)
                Toast.makeText(this, "se modificaron los datos", Toast.LENGTH_SHORT)
                        .show();
            else
                Toast.makeText(this, "no existe un producto con el código ingresado",
                        Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "La cantidad a comprar es mayor al stock actual",
                    Toast.LENGTH_SHORT).show();
        }
    }
     */
}
