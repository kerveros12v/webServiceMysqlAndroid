package com.example.formulario2;
        import androidx.appcompat.app.AlertDialog;
        import androidx.appcompat.app.AppCompatActivity;

        import android.content.ContentValues;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.RadioButton;
        import android.widget.Spinner;
        import android.widget.Toast;

        import com.android.volley.AuthFailureError;
        import com.android.volley.Request;
        import com.android.volley.RequestQueue;
        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.JsonArrayRequest;
        import com.android.volley.toolbox.StringRequest;
        import com.android.volley.toolbox.Volley;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

        import java.util.HashMap;
        import java.util.Map;

public class Persona extends AppCompatActivity {
    private String []opcionespais={"Ecuador","Venezuela","Colombia"};
private RequestQueue requestQueue;
    private EditText etcedula,etnombre,etdireccion,provincias,etapellido;
    private Spinner paises;
    private RadioButton rbthombre,rbtmujer;
    private String sexo="";
    private String cedulabase="";
    ArrayAdapter<String> adapterpais=null;
    private Button btninsertar,btnactualizar,btneliminar,btnbuscar;
private String urlbase="http://192.168.0.105/formulario/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persona);

        etcedula=(EditText)findViewById(R.id.etcedula);
        etnombre=(EditText)findViewById(R.id.etnombre);
        etdireccion=(EditText)findViewById(R.id.etdireccion);
        etapellido=(EditText)findViewById(R.id.etapellido);
        rbthombre=(RadioButton)findViewById(R.id.rbthombre);
        rbtmujer=(RadioButton)findViewById(R.id.rbtmujer);

        paises=(Spinner) findViewById(R.id.sppais);
        adapterpais=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,opcionespais);
        paises.setAdapter(adapterpais);

        provincias=(EditText) findViewById(R.id.etprovincia);
        btnactualizar=(Button)findViewById(R.id.btnpersonaactualizar);
        btnbuscar=(Button)findViewById(R.id.btnpersonabuscar);
        btneliminar=(Button)findViewById(R.id.btnpersonaborrar);
        btninsertar=(Button)findViewById(R.id.btnpersonagurdar);
        sexos();

        activarBotones();
       /* btnbuscar.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

            }
        });
        */
    }
    //funciones de botones

    public  void activarBotones(){
        Bundle bundle = getIntent().getExtras();
        String usuario=bundle.getString("cedula");
        String administrador=bundle.getString("usuario");
        if(!usuario.equals("12345")&& !administrador.equals("admin")){
            etcedula.setText(usuario);
            etnombre.setText(administrador);
        }

        if (!administrador.equals("admin")){
        btninsertar.setVisibility(View.INVISIBLE);
        btneliminar.setVisibility(View.INVISIBLE);
        btnbuscar.setVisibility(View.INVISIBLE);

            consultaporcedula1(usuario);
        }

    }
    private void sexos() {
        if(rbtmujer.isChecked()==true){
            sexo="Mujer";
        }else{
            sexo="Hombre";
        }
    }
    public void borrar(View view){
       // mensajeAlert("Accion Borrar","Metodo");
        ejecutarServico(urlbase+"eliminardato.php");
    }
    public void modificacion(View view){
        //mensajeAlert("Accion Actualizar","Metodo");
        ejecutarServico(urlbase+"actualizardato.php");
    }
    public void guardar(View view){
        //mensajeAlert("Accion Guardar","Metodo");
        ejecutarServico(urlbase+"insertardatos.php");
    }
    private void ejecutarServico(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                //mensajeAlert(response.toString(),"Respuesta del servidor");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mensajeAlert(error.getMessage(),"Error en el servicio");
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                sexos();
                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("nombres",Persona.this.etnombre.getText().toString());
                parametros.put("apellidos",Persona.this.etapellido.getText().toString());
                parametros.put("cedula",Persona.this.etcedula.getText().toString());
                parametros.put("sexo",Persona.this.sexo);
                parametros.put("pais",Persona.this.paises.getSelectedItemPosition()+"");
                parametros.put("provincia",Persona.this.provincias.getText().toString());
                parametros.put("direccion",Persona.this.etdireccion.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
      // mensajeAlert("Servicio Finalizado","Info");
    }
    private void buscar(String URL){


        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                if (response.length()!=0) {

                    for (int i = 0; i < response.length(); i++) {
                        try {
                            jsonObject = response.getJSONObject(i);
                            Persona.this.etnombre.setText(jsonObject.getString("nombres"));
                            Persona.this.etapellido.setText(jsonObject.getString("apellidos"));
                            Persona.this.etcedula.setText(jsonObject.getString("cedula"));
                            Persona.this.provincias.setText(jsonObject.getString("provincia"));
                            Persona.this.etdireccion.setText(jsonObject.getString("direccion"));
                            int pos=jsonObject.getInt("pais");
                            Persona.this.paises.setSelection(adapterpais.getPosition(opcionespais[pos>1?pos-1:pos]));
                            String sex=jsonObject.getString("sexo");
                            if(sex.equals("Mujer"))rbtmujer.setChecked(true);
                            else rbthombre.setChecked(true);
                        } catch (JSONException e) {
                            mensajeAlert(e.getMessage(), "Error en el array");
                        }

                    }
                }else{
                    mensajeAlert("No existe ningun registro con esa Cedula", "Respuesta del servidor");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mensajeAlert(error.getMessage(),"Error");
            }
        }
        );

        requestQueue=Volley.newRequestQueue(Persona.this);
        requestQueue.add(jsonArrayRequest);
    }

    private void  mensajeAlert(String e,String titulo){
        AlertDialog.Builder builder=new AlertDialog.Builder(Persona.this);
        builder.setMessage(e);
        builder.setTitle(titulo);
        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog= builder.create();
        dialog.show();
    }
    public void consultaporcedula(View view) {
        //mensajeAlert("Accion del Boton Buscar","info");
       consultaporcedula1(String.valueOf(etcedula.getText()));

    }
    private void consultaporcedula1(String cod){

        buscar(urlbase+"buscardatos.php?cedula="+cod);
        //Toast.makeText(this, "Se realizo la busqueda", Toast.LENGTH_SHORT).show();
    }
    public void regresar(View view){
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }


    ///version sqlLite
    /*
    public void guardar(View v) {
        sexos();
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cedula = etcedula.getText().toString();
        String nombre = etnombre.getText().toString();
        String direccion = etdireccion.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("cedula", cedula);
        registro.put("nombre", nombre);
        registro.put("sexo",sexo);
        registro.put("pais",paises.getSelectedItem().toString());
        registro.put("provincia",provincias.getText().toString());
        registro.put("direccion",direccion);
        bd.insert("persona", null, registro);
        bd.close();
        etcedula.setText("");
        etnombre.setText("");
        etdireccion.setText("");
        Toast.makeText(this, "Se cargaron los datos de la Persona", Toast.LENGTH_SHORT).show();
    }
    private void consultaporcedula1(String cod){
        try {
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                    "administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();

            Cursor fila = bd.rawQuery(
                    "select cedula,nombre,sexo,pais,provincia,direccion from persona where cedula=" + cod, null);
            if (fila.moveToFirst()) {
                etcedula.setText(fila.getString(0));
                etnombre.setText(fila.getString(1));
                etdireccion.setText(fila.getString(5));
                cedulabase=fila.getString(0);
                paises.setSelection(adapterpais.getPosition(fila.getString(3)));
                provincias.setText(fila.getString(4));
                String sex=fila.getString(2);
                if(sex.equals("Mujer"))rbtmujer.setChecked(true);
                else rbthombre.setChecked(true);

            } else
                Toast.makeText(this, "No existe una persona con dicho código",
                        Toast.LENGTH_SHORT).show();
            bd.close();
        }catch (Exception ex){
            Toast.makeText(this, ex.getMessage().toString(),
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void borrar(View v) {
        try {
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                    "administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();
            String cod = etcedula.getText().toString();
            int cant = bd.delete("persona", "cedula=" + cod, null);
            bd.close();
            etcedula.setText("");
            etnombre.setText("");
            etdireccion.setText("");
            if (cant == 1)
                Toast.makeText(this, "Se borró la persona con dicha cedula",
                        Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "No existe una persona com  dicha cedula",
                        Toast.LENGTH_SHORT).show();
        }catch (Exception ex){
            Toast.makeText(this, ex.getMessage().toString(),
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void modificacion(View v) {
        sexos();
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cedula = etcedula.getText().toString();
        String nombre = etnombre.getText().toString();
        String direccion = etdireccion.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("cedula", cedula);
        registro.put("nombre", nombre);
        registro.put("sexo",sexo);
        registro.put("pais",paises.getSelectedItem().toString());
        registro.put("provincia",provincias.getText().toString());
        registro.put("direccion",direccion);
        int cant = bd.update("persona", registro, "cedula=" + cedulabase, null);
        bd.close();
        if (cant == 1)
            Toast.makeText(this, "se modificaron los datos", Toast.LENGTH_SHORT)
                    .show();
        else
            Toast.makeText(this, "no existe una persona con la cedula ingresada",
                    Toast.LENGTH_SHORT).show();
    }
*/
    ///////////////////////////////////////////////////////////////////77
}
