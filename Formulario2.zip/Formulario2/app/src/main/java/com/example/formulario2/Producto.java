package com.example.formulario2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.formulario2.AdminSQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Producto extends AppCompatActivity {
EditText etcodigo,etdescripcion,etstock,etcosto,etventa;
TextView etvutilidad;
RequestQueue requestQueue;
String urlbase="http://192.168.0.105/formulario/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producto);
        etcodigo=(EditText)findViewById(R.id.etcodigo);
        etdescripcion=(EditText)findViewById(R.id.etdetallle);
        etstock=(EditText)findViewById(R.id.etstock);
        etcosto=(EditText)findViewById(R.id.etpreciocosto);
        etventa=(EditText)findViewById(R.id.etprecioventa);
        etvutilidad=(TextView)findViewById(R.id.etvutilidad);
    }

    private void buscar(String URL){
        String[] s=null ;
        // mensajeAlert("Direccion obtenida: "+URL);
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                // mensajeAlert("Numero de elementos optenidos: "+response.length());
                String[] opciones=new String[response.length()];
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        etcodigo.setText(jsonObject.getString("codigo"));
                        etdescripcion.setText(jsonObject.getString("nombre"));
                        etstock.setText(jsonObject.getString("stock"));
                        etcosto.setText(jsonObject.getString("precioCosto"));
                        etventa.setText(jsonObject.getString("precioVenta"));
                        etvutilidad.setText(jsonObject.getString("ganancia"));
                    } catch (JSONException e) {
                        mensajeAlert(e.getMessage(),"Error en el array");
                    }

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mensajeAlert(error.getMessage(),"Error");
            }
        }
        );

        requestQueue=Volley.newRequestQueue(Producto.this);
        requestQueue.add(jsonArrayRequest);
    }
    private void ejecutarServico(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                mensajeAlert(response.toString(),"Respuesta del servidor");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mensajeAlert(error.getMessage(),"Servicio Volley");
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                totalutilidad();
                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("codigo",Producto.this.etcodigo.getText().toString());
                parametros.put("nombre",Producto.this.etdescripcion.getText().toString());
                parametros.put("stock",Producto.this.etstock.getText().toString());
                parametros.put("precioCosto",Producto.this.etcosto.getText().toString());
                parametros.put("precioVenta",Producto.this.etventa.getText().toString());
                parametros.put("ganancia",Producto.this.etvutilidad.getText().toString());

                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(Producto.this);
        requestQueue.add(stringRequest);
        //Toast.makeText(this,"Servicio ejecutado con exito",Toast.LENGTH_LONG).show();
    }
    public void consultaporcodigo(View v){
        buscar(urlbase+"buscarProducto.php?codigo="+etcodigo.getText().toString());
    }
    public void consultapordescripcion(View v){
        buscar(urlbase+"buscarProductoNombre.php?nombre="+etdescripcion.getText()+"");

    }
    public void utilidad(View view){
        totalutilidad();
    }
public  void totalutilidad(){
        try {
            if(!etventa.getText().toString().equals("") || !etcosto.getText().toString().equals(""))
            etvutilidad.setText("" + (Double.parseDouble(etventa.getText().toString()) - Double.parseDouble(etcosto.getText().toString())));
        }catch (Exception e){
            //etvutilidad.setText("");
        }
}

    public void bajaporcodigo(View v) {
ejecutarServico(urlbase+"eliminarproducto.php");
    }
    public void alta(View v) {
        ejecutarServico(urlbase+"insertarProducto.php");
    }
    public void modificacion(View v) {
        ejecutarServico(urlbase+"actualizarproducto.php");
    }
    public void regresar(View view){
        Intent i=null;
        i = new Intent(this, MainActivity.class );

        startActivity(i);
    }
    private void  mensajeAlert(String e,String titulo){
        AlertDialog.Builder builder=new AlertDialog.Builder(Producto.this);
        builder.setMessage(e);
        builder.setTitle(titulo);
        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog= builder.create();
        dialog.show();
    }
    /*Formato sqlite
     public void alta(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = etcodigo.getText().toString();
        String descri = etdescripcion.getText().toString();
        String stock = etstock.getText().toString();
        String compra=etcosto.getText().toString();
        String venta=etventa.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("codigo", cod);
        registro.put("descripcion", descri);
        registro.put("stock", stock);
        registro.put("costo", compra);
        registro.put("venta", venta);
        bd.insert("producto", null, registro);
        bd.close();
        etcodigo.setText("");
        etdescripcion.setText("");
        etstock.setText("");
        etcosto.setText("");
        etventa.setText("");
        etvutilidad.setText("");
        Toast.makeText(this, "Se cargaron los datos del artículo",
                Toast.LENGTH_SHORT).show();
    }
public void consultaporcodigo(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = etcodigo.getText().toString();
        Cursor fila = bd.rawQuery(
                "select descripcion,stock,costo,venta from producto where codigo=" + cod, null);
        if (fila.moveToFirst()) {
            etdescripcion.setText(fila.getString(0));
            etstock.setText(fila.getString(1));
            etcosto.setText(fila.getString(2));
            etventa.setText(fila.getString(3));
        } else
            Toast.makeText(this, "No existe un producto con dicho código",
                    Toast.LENGTH_SHORT).show();
        bd.close();
        totalutilidad();
    }
    public void consultapordescripcion(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String descri = etdescripcion.getText().toString();
        Cursor fila = bd.rawQuery(
                "select codigo,stock,costo,venta from producto where descripcion='" + descri + "'", null);
        if (fila.moveToFirst()) {
            etcodigo.setText(fila.getString(0));
            etstock.setText(fila.getString(1));
            etcosto.setText(fila.getString(2));
            etventa.setText(fila.getString(3));
        } else
            Toast.makeText(this, "No existe un producto con dicha descripción",
                    Toast.LENGTH_SHORT).show();
        bd.close();
        totalutilidad();
    }
     public void bajaporcodigo(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = etcodigo.getText().toString();
        int cant = bd.delete("producto", "codigo=" + cod, null);
        bd.close();
        etcodigo.setText("");
        etdescripcion.setText("");
        etstock.setText("");
        etcosto.setText("");
        etventa.setText("");
        etvutilidad.setText("");
        if (cant == 1)
            Toast.makeText(this, "Se borró el producto con dicho código",
                    Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "No existe un producto con dicho código",
                    Toast.LENGTH_SHORT).show();
    }

    public void modificacion(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = etcodigo.getText().toString();
        String descri = etdescripcion.getText().toString();
        String stock = etstock.getText().toString();
        String costo=etcosto.getText().toString();
        String venta=etventa.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("codigo", cod);
        registro.put("descripcion", descri);
        registro.put("stock", stock);
        registro.put("costo", costo);
        registro.put("venta", venta);
        int cant = bd.update("producto", registro, "codigo=" + cod, null);
        bd.close();
        if (cant == 1)
            Toast.makeText(this, "se modificaron los datos", Toast.LENGTH_SHORT)
                    .show();
        else
            Toast.makeText(this, "no existe un producto con el código ingresado",
                    Toast.LENGTH_SHORT).show();
    }
     */
}
