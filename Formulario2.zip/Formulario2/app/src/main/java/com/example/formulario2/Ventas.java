package com.example.formulario2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Ventas extends AppCompatActivity {
    EditText vencodig,vencantidad;
    TextView vendetall,venstock,venprecio,ventotal;
    Double precio1;
    Double stk;
    RequestQueue requestQueue;
    String urlbase="http://192.168.0.105/formulario/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas);
        vencodig=(EditText)findViewById(R.id.etventascodigo);
        vencantidad=(EditText)findViewById(R.id.etventascantidad);
        vendetall=(TextView)findViewById(R.id.etvventasdetalle);
        venstock=(TextView)findViewById(R.id.etvventasStock);
        venprecio=(TextView)findViewById(R.id.etvventasprecio);
        ventotal=(TextView)findViewById(R.id.etvventastotal);
    }
    private void buscar(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        vencodig.setText(jsonObject.getString("codigo"));
                        vendetall.setText(jsonObject.getString("nombre"));
                        venstock.setText(jsonObject.getString("stock"));
                        venprecio.setText(jsonObject.getString("precioVenta"));
                        precio1=Double.parseDouble(jsonObject.getString("ganancia"));
                        stk=Double.parseDouble(jsonObject.getString("stock"));
                        Toast.makeText(getApplicationContext(), "Registro encontrado", Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    private void ejecutarServico(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("codigo",vencodig.getText().toString());
                parametros.put("nombre",vendetall.getText().toString());
                parametros.put("stock",venstock.getText().toString());
                parametros.put("precioVenta",venprecio.getText().toString());

                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
        Toast.makeText(this,"Servicio ejecutado con exito",Toast.LENGTH_LONG).show();
    }
    public void consultaporcodigo(View v) {
        buscar(urlbase+"buscarProducto.php?codigo="+vencodig.getText().toString());
    }
    public void modificacion(View v) {
        double cant1=Double.parseDouble(vencantidad.getText().toString());
        if(cant1<=stk) {

            String cod = vencodig.getText().toString();
            stk = stk - cant1;
            String stock = stk + "";
            venstock.setText(stock);
            ejecutarServico(urlbase+"actualizarproductoStock.php");

        }
        else{
            Toast.makeText(this, "La cantidad a comprar es mayor al stock actual",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void totalPagar(View view){
        try {
            double p1 = Double.parseDouble(venprecio.getText().toString());
            double cant1 = Double.parseDouble(vencantidad.getText().toString());
            if(cant1>0) {
                double total = p1 * cant1;
                ventotal.setText("Total:  " + total);
            }
            else      Toast.makeText(this, "Ingrese una cantidad valida ",
                    Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(this, "No a ingresado la cantidad a Comprar ",
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void regresar(View view){
        Intent i=null;
        i = new Intent(this, Inventario.class );

        startActivity(i);
    }
    /*
    public void consultaporcodigo(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = vencodig.getText().toString();
        Cursor fila = bd.rawQuery(
                "select descripcion,stock,venta from producto where codigo=" + cod, null);
        if (fila.moveToFirst()) {
            vendetall.setText("Descripcion:   " + fila.getString(0));
            venstock.setText("Stock:         "+fila.getString(1));
            venprecio.setText("Precio:        "+fila.getString(2));
            precio1=Double.parseDouble(fila.getString(2));
            stk=Double.parseDouble(fila.getString(1));
        } else
            Toast.makeText(this, "No existe un producto con dicho código",
                    Toast.LENGTH_SHORT).show();
        bd.close();
    }
    public void modificacion(View v) {
        double cant1=Double.parseDouble(vencantidad.getText().toString());
        if(cant1<=stk) {
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                    "administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();
            String cod = vencodig.getText().toString();
            stk = stk - cant1;
            String stock = stk + "";
            ContentValues registro = new ContentValues();
            registro.put("stock", stock);
            int cant = bd.update("producto", registro, "codigo=" + cod, null);
            bd.close();
            if (cant == 1)
                Toast.makeText(this, "se modificaron los datos", Toast.LENGTH_SHORT)
                        .show();
            else
                Toast.makeText(this, "no existe un producto con el código ingresado",
                        Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "La cantidad a comprar es mayor al stock actual",
                    Toast.LENGTH_SHORT).show();
        }
    }
     */
}
