package com.example.formulario2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private String []opciones={"Producto","Persona","Inventario"};
    private Spinner ventanas;
    EditText clave,usuario;
    String urlbase="http://192.168.0.105/formulario/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ventanas=(Spinner) findViewById(R.id.seccion);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,opciones);
        ventanas.setAdapter(adapter);
        clave=(EditText)findViewById(R.id.etpass);
        usuario=(EditText)findViewById(R.id.etuser);
    }
    public void consultapornombre() {

        RequestQueue requestQueue;


        String URL=urlbase+"buscardatosU.php?cedula="+clave.getText().toString()+"&nombres="+usuario.getText().toString();
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

               if (response.length()!=0) {
                   Toast.makeText(getApplicationContext(),"Usuario Encontrado",Toast.LENGTH_SHORT).show();
                   cargarPantalla();
               }
               else{
                   Toast.makeText(getApplicationContext(),"Usuario NO Encontrado",Toast.LENGTH_SHORT).show();
               }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion : "+error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);

    }
    public  void seleccionopcion(View view) {
        if (clave.getText().toString().equals("12345") && usuario.getText().toString().equals("admin")) {

           cargarPantalla();
        }
       else  consultapornombre();
    }
    private void cargarPantalla(){
        String op = ventanas.getSelectedItem().toString();
        Intent i = null;
        if (op.equals("Persona")) {

            i = new Intent(this, Persona.class);
            i.putExtra("cedula", clave.getText().toString());
            i.putExtra("usuario",usuario.getText().toString());
            Toast.makeText(this, "Persona",
                    Toast.LENGTH_SHORT).show();
        } else if (op.equals("Producto")) {

            i = new Intent(this, Producto.class);
            Toast.makeText(this, "Producto",
                    Toast.LENGTH_SHORT).show();


        } else if (op.equals("Inventario")) {

            i = new Intent(this, Inventario.class);
            Toast.makeText(this, "Inventario",
                    Toast.LENGTH_SHORT).show();


        }
        startActivity(i);
    }
    /*
    public boolean consultapornombre() {
       try{
           AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,
                   "administracion", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();
        String cod = "";
        cod=usuario.getText().toString();
        String cedula1="";
        cedula1=clave.getText().toString();
        String query1=String.format("select cedula,nombre from persona where cedula=%s",cedula1);
        Cursor fila = bd.rawQuery(query1, null);
        if (fila.moveToFirst()) {
            if(cod.equals(fila.getString(1))) {
                bd.close();
                return true;
            }
        }
        bd.close();
        return false;
       }catch (Exception ex){
           return false;
       }
    }
     */
}
