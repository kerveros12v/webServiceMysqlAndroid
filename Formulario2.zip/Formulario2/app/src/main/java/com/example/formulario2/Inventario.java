package com.example.formulario2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class Inventario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventario);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuinventario, menu);
        return true;
    }

    @Override
    public boolean
    onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent i=null;
        if (id==R.id.idcompras) {
            Toast.makeText(this,"Se seleccionó  Compras",Toast.LENGTH_LONG).show();
            i = new Intent(this, Compras.class );
        }
        if (id==R.id.idsalirinventario) {
            i = new Intent(this, MainActivity.class );
            Toast.makeText(this,"Se seleccionó Salir",Toast.LENGTH_LONG).show();
        }
        if (id==R.id.idventa) {
            i = new Intent(this, Ventas.class );
            Toast.makeText(this,"Se seleccionó Venta",Toast.LENGTH_LONG).show();
        }
        startActivity(i);
               return super.onOptionsItemSelected(item);
    }


}
